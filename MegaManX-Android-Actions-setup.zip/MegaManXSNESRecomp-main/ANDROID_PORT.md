# Android port

The Android port is an Android Studio project under `android/` using Gradle, CMake, SDL3 and the SDL Android activity glue.

The native game target becomes a shared library on Android. Desktop-only host setup is disabled for Android. The Android build targets arm64-v8a and includes touch controls for D-pad, A/B/X/Y, L/R and Start.

The repository still requires the pinned `snesrecomp` and `recomp-ui` submodules and a locally supplied Mega Man X USA Rev 1 ROM to generate `src/gen`. Those generated sources and the ROM are intentionally not included in this ZIP.

Run `tools/setup_android_deps.sh` once, then open `android/` in Android Studio and build `app`.
