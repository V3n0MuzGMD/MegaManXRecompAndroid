# Mega Man X SNES Recomp Android port

This is the Android build layer for the supplied MegaManXSNESRecomp tree.

## Requirements

* Android Studio or Gradle 8.x
* Android SDK 35+
* Android NDK r28c+
* SDL3 Android AAR 3.4.10 placed at `app/libs/SDL3-3.4.10.aar`
* The two git submodules from the project: `snesrecomp/` and `recomp-ui/`
* A legally obtained matching Mega Man X USA Rev 1 ROM to regenerate `src/gen/`

SDL documents Android support with the same AAR + CMake + Prefab model used here. The minimum Android API supported by current SDL is 21.

## Setup

From the repository root:

```bash
git submodule update --init --recursive
bash tools/regen.sh usa --no-tests
```

Then put the SDL AAR in `android-project/app/libs/` and build:

```bash
cd android-project
./gradlew assembleDebug
```

The APK is written under `app/build/outputs/apk/debug/`.

## Important

The original repository intentionally does not redistribute ROM-derived generated C. A build without `src/gen/*.c` cannot produce the playable game. This Android layer therefore does not contain a ROM or generated game code.
