package com.megamanx.recomp;

import org.libsdl.app.SDLActivity;

/** SDL3 Android entry point for Mega Man X SNES Recomp. */
public class MainActivity extends SDLActivity { }
