#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

git submodule update --init --recursive

if [ ! -f android-project/app/libs/SDL3-3.4.10.aar ]; then
  echo "Missing SDL3-3.4.10.aar"
  echo "Download the SDL3 3.4.10 Android development archive from the official SDL release and copy SDL3-3.4.10.aar to android-project/app/libs/"
  exit 2
fi

if [ ! -d src/gen ] || ! compgen -G 'src/gen/*.c' >/dev/null; then
  echo "Missing src/gen/*.c"
  echo "Stage your legally obtained matching USA Rev 1 ROM as mmx.sfc and run: bash tools/regen.sh usa --no-tests"
  exit 3
fi

echo "Android prerequisites are present."
