#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

git submodule update --init --recursive

if [ ! -d third_party/SDL3/.git ]; then
  rm -rf third_party/SDL3
  git clone --depth 1 https://github.com/libsdl-org/SDL.git third_party/SDL3
fi

echo "Android dependencies ready."
echo "Open android/ in Android Studio and build the app module."
