#!/usr/bin/env bash
# make_release_rmx.sh — build the Rockman X (Japan v1.1) Windows release zip.
#
# Both regions use the shared CMake build; this helper packages JP.
# Stage layout mirrors tools/make_release.ps1 (the USA release):
#   RockmanXSNESRecomp.exe  (Release, console-free via -mwindows)
#   SDL2.dll + mingw runtime DLLs (bundled via ldd so it runs without msys2)
#   config.ini              (repo copy — the launcher rewrites it in place)
#   assets/                 (shared Dear ImGui assets + per-game boxart)
#   README.md
#
# Zip lands in release-stage/RockmanXSNESRecomp-windows-<Version>.zip.
# Usage: bash tools/make_release_rmx.sh [Version]   (default 0.1.0)
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
VERSION="${1:-0.1.0}"
export PATH="/c/msys64/mingw64/bin:$PATH"

BUILD="$ROOT/build-release-jp"
STAGE_NAME="RockmanXSNESRecomp-windows-$VERSION"
STAGE="$ROOT/release-stage/$STAGE_NAME"
ZIP="$ROOT/release-stage/$STAGE_NAME.zip"

echo "=== configure + build (mingw Release, console-free) ==="
cmake -S "$ROOT" -B "$BUILD" -G Ninja \
  -DCMAKE_BUILD_TYPE=Release \
  -DCMAKE_C_COMPILER=C:/msys64/mingw64/bin/gcc.exe \
  -DSNESRECOMP_SDL_BACKEND=SDL2 \
  -DSDL2_DIR=C:/msys64/mingw64/lib/cmake/SDL2 \
  -DCMAKE_EXE_LINKER_FLAGS="-mwindows"
cmake --build "$BUILD" --target RockmanXSNESRecomp -j6

EXE="$BUILD/RockmanXSNESRecomp.exe"
[ -f "$EXE" ] || { echo "build produced no exe" >&2; exit 1; }

echo "=== stage ==="
rm -rf "$STAGE"; mkdir -p "$STAGE/assets"
cp "$EXE" "$STAGE/"
cp "$ROOT/config.ini" "$STAGE/"
[ -f "$ROOT/README.md" ] && cp "$ROOT/README.md" "$STAGE/"

# The shared recomp-ui CMake integration stages all launcher assets, including
# the per-game box art, next to the built executable.
[ -d "$BUILD/assets" ] || { echo "build produced no assets directory" >&2; exit 1; }
cp -r "$BUILD/assets/." "$STAGE/assets/"

# Bundle the runtime DLLs the mingw exe links (SDL2 + libgcc/libstdc++/
# libwinpthread/etc.) so it runs on a machine without msys2. ldd lists them;
# copy only the ones under the mingw prefix (system DLLs stay on the target).
echo "=== bundle mingw runtime DLLs ==="
ldd "$EXE" | awk '/mingw64/ {print $3}' | while read -r dll; do
  [ -f "$dll" ] && cp -u "$dll" "$STAGE/" && echo "  + $(basename "$dll")"
done
# SDL2 is dlopen'd/linked; ensure it's present even if ldd missed it.
[ -f "$STAGE/SDL2.dll" ] || cp /c/msys64/mingw64/bin/SDL2.dll "$STAGE/"

echo "=== zip ==="
rm -f "$ZIP"
if command -v zip >/dev/null 2>&1; then
  ( cd "$STAGE" && zip -qr "$ZIP" . )
else
  powershell.exe -NoProfile -Command "Compress-Archive -Path '$(cygpath -w "$STAGE")\*' -DestinationPath '$(cygpath -w "$ZIP")' -Force"
fi

echo "=== $STAGE_NAME ==="
ls -la "$STAGE"
echo "--- zip ---"; ls -la "$ZIP"
