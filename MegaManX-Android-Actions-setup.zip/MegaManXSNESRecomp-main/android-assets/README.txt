Runtime assets for the Android build.

Do not put a copyrighted Mega Man X ROM here.
The generated C sources are also not included. Supply your legally obtained ROM and run tools/regen.sh on a development machine before building the game target.
