# Mega Man X Recompiled Android port

This is the Android Studio/Gradle wrapper for MegaManXSNESRecomp.

## One-time setup

From the repository root run `bash tools/setup_android_deps.sh`.

It initializes `snesrecomp`, `recomp-ui`, and SDL3. The game source is then built through the normal Android CMake toolchain.

A legally obtained Mega Man X (USA Rev 1) ROM is still required. The ROM is not included.

## Build

Open the `android/` directory in Android Studio and build the `app` module, or run:

`./gradlew :app:assembleDebug`

The current Android configuration targets arm64-v8a, minSdk 21, targetSdk 36, and NDK 28.2.
