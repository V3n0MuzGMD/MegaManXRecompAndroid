package com.megamanx.recomp;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;

import org.libsdl.app.SDLActivity;

import java.util.HashMap;
import java.util.Map;

public final class TouchControlsView extends View {
    private static final class Button {
        final String label;
        final int key;
        final RectF rect = new RectF();
        Button(String label, int key) { this.label = label; this.key = key; }
    }

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Button left = new Button("<", KeyEvent.KEYCODE_DPAD_LEFT);
    private final Button right = new Button(">", KeyEvent.KEYCODE_DPAD_RIGHT);
    private final Button up = new Button("^", KeyEvent.KEYCODE_DPAD_UP);
    private final Button down = new Button("v", KeyEvent.KEYCODE_DPAD_DOWN);
    private final Button a = new Button("A", KeyEvent.KEYCODE_X);
    private final Button b = new Button("B", KeyEvent.KEYCODE_Z);
    private final Button x = new Button("X", KeyEvent.KEYCODE_S);
    private final Button y = new Button("Y", KeyEvent.KEYCODE_A);
    private final Button l = new Button("L", KeyEvent.KEYCODE_C);
    private final Button r = new Button("R", KeyEvent.KEYCODE_V);
    private final Button start = new Button("START", KeyEvent.KEYCODE_ENTER);
    private final Map<Integer, Button> active = new HashMap<>();
    private final Button[] buttons = {left,right,up,down,a,b,x,y,l,r,start};

    public TouchControlsView(android.content.Context context) {
        super(context);
        setFocusable(false);
        paint.setTextAlign(Paint.Align.CENTER);
    }

    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        float w = getWidth(), h = getHeight();
        float s = Math.min(w, h) * 0.105f;
        float gap = s * 0.12f;

        float cx = s * 1.55f, cy = h - s * 1.65f;
        down.rect.set(cx-s/2, cy+gap, cx+s/2, cy+s+gap);
        up.rect.set(cx-s/2, cy-s-gap, cx+s/2, cy-gap);
        left.rect.set(cx-s-gap, cy-s/2, cx-gap, cy+s/2);
        right.rect.set(cx+gap, cy-s/2, cx+s+gap, cy+s/2);

        float bx = w - s * 2.15f, by = h - s * 1.85f;
        b.rect.set(bx-s/2, by-s/2, bx+s/2, by+s/2);
        a.rect.set(bx+s*0.9f-s/2, by-s/2, bx+s*0.9f+s/2, by+s/2);
        y.rect.set(bx-s*0.45f-s/2, by-s*0.9f-s/2, bx-s*0.45f+s/2, by-s*0.9f+s/2);
        x.rect.set(bx+s*0.45f-s/2, by-s*0.9f-s/2, bx+s*0.45f+s/2, by-s*0.9f+s/2);
        l.rect.set(w-s*3.9f, h-s*1.05f, w-s*3.05f, h-s*0.45f);
        r.rect.set(w-s*2.75f, h-s*1.05f, w-s*1.9f, h-s*0.45f);
        start.rect.set(w/2-s*0.8f, h-s*0.9f, w/2+s*0.8f, h-s*0.35f);

        paint.setTextSize(s*0.32f);
        for (Button button : buttons) {
            paint.setStyle(Paint.Style.FILL);
            paint.setAlpha(active.containsValue(button) ? 120 : 70);
            c.drawRoundRect(button.rect, s*0.18f, s*0.18f, paint);
            paint.setStyle(Paint.Style.STROKE);
            paint.setAlpha(150);
            c.drawRoundRect(button.rect, s*0.18f, s*0.18f, paint);
            paint.setStyle(Paint.Style.FILL);
            paint.setAlpha(220);
            c.drawText(button.label, button.rect.centerX(), button.rect.centerY()+paint.getTextSize()*0.35f, paint);
        }
    }

    @Override public boolean onTouchEvent(MotionEvent event) {
        int action = event.getActionMasked();
        if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_POINTER_DOWN || action == MotionEvent.ACTION_MOVE) {
            int count = event.getPointerCount();
            for (int i=0; i<count; i++) {
                int id = event.getPointerId(i);
                Button hit = hit(event.getX(i), event.getY(i));
                Button old = active.get(id);
                if (old != hit) {
                    if (old != null) SDLActivity.onNativeKeyUp(old.key);
                    if (hit != null) SDLActivity.onNativeKeyDown(hit.key);
                    if (hit == null) active.remove(id); else active.put(id, hit);
                }
            }
            invalidate();
            return true;
        }
        if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_POINTER_UP || action == MotionEvent.ACTION_CANCEL) {
            int index = event.getActionIndex();
            int id = event.getPointerId(index);
            Button old = active.remove(id);
            if (old != null) SDLActivity.onNativeKeyUp(old.key);
            if (action == MotionEvent.ACTION_CANCEL) {
                for (Button b : active.values()) SDLActivity.onNativeKeyUp(b.key);
                active.clear();
            }
            invalidate();
            return true;
        }
        return true;
    }

    private Button hit(float px, float py) {
        for (Button b : buttons) if (b.rect.contains(px, py)) return b;
        return null;
    }
}
