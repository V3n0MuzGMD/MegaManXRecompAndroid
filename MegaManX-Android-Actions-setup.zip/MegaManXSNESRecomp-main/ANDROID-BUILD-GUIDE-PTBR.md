# Gerar APK Android pelo GitHub Actions

Este repositório inclui uma tentativa de build automatizado. O workflow **não inclui nem baixa uma ROM**.

## Antes de executar

1. Use um repositório **privado** para seu projeto pessoal.
2. Coloque sua própria cópia legal da ROM Mega Man X USA Rev 1 na raiz do repositório, com o nome `mmx.sfc`. Não publique a ROM nem os arquivos gerados derivados dela.
3. Confira se os submódulos `snesrecomp` e `recomp-ui` estão inicializados no repositório.

## No celular

1. Abra a aba **Actions** do repositório.
2. Escolha **Build Mega Man X Android APK**.
3. Toque em **Run workflow**.
4. Espere terminar. Se ficar verde, abra a execução e baixe o artefato `MegaManX-Android-debug-apk`.

Se falhar, abra a execução e copie as últimas linhas vermelhas do log. Esta configuração é uma primeira tentativa: o projeto pode precisar de ajustes no Gradle/NDK ou no ambiente do recompilador antes de produzir um APK funcional.
